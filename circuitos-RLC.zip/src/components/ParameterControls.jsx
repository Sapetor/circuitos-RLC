import React from "react";
// This component is now unused. Controls are in App.js.
const ParameterControls = () => null;
export default ParameterControls; 